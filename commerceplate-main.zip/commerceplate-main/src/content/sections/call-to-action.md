---
enable: true
title: "Curved Collection for Your Bedroom Get 25% Off"
sub_title: "Deal of the Week"
image: "/images/call-to-action.png"
description: "Subscribe our Newsletter and get all latest information and offers"
button:
  enable: true
  label: "Shop Now"
  link: "/products"
---
